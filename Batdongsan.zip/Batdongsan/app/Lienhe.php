<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lienhe extends Model
{
    protected $table = 'lien_he';
    public $timestamps = false;
}
