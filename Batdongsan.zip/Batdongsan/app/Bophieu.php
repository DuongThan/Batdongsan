<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bophieu extends Model
{
    protected $table = 'bo_phieu';
    public $timestamps = false;
}
