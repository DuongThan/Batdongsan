<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThanhvienBophieu extends Model
{
    protected $table = 'thanhvien_bophieu';
    public $timestamps = false;
}
