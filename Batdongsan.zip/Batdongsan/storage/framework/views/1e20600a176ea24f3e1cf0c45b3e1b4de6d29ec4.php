<?php $__env->startSection('title', 'ĐĂNG TIN NHÀ ĐẤT'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
					<?php if(!session('id_thanh_vien')): ?>
					<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
						<div class="alert alert-warning">
						  <h3>Bạn phải đăng nhập mới có thể đăng tin!</h3>
						</div>
					</div>
					<?php else: ?>
					<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">ĐĂNG TIN NHÀ ĐẤT MIỄN PHÍ</h3>
						<?php if(count($errors) > 0): ?>
                          <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>  
                        <?php if(session('thongbao')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('thongbao')); ?>

                          </div>
                        <?php endif; ?>
						<form action="<?php echo e(route('dang-tin')); ?>" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="tieude">Tiêu đề <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="tieude" placeholder="Tiêu đề" name="tieu_de" value="<?php echo e(old('tieu_de')); ?>">
							</div>
							<div class="form-group">
								<label for="noidung">Nội dung <span style="color:#FF0000;">(*)</span>:</label>
								<textarea class="form-control" rows="5" id="noidung" placeholder="Nội dung" name="noi_dung"><?php echo e(old('noi_dung')); ?></textarea>
							</div>
							<div class="form-group">
								<label for="loaitin">Loại tin <span style="color:#FF0000;">(*)</span>:</label>
								<select class="form-control" id="loaitin" name="loai_tin">
									<option value="">Chọn loại tin</option>
									<option value="Cần bán">Cần bán</option>
									<option value="Cần mua">Cần mua</option>
									<option value="Cho Thuê">Cho thuê</option>
									<option value="Cần thuê">Cần thuê</option>
								</select>
							</div>
							<div class="form-group">
								<label for="loaibatdongsan">Loại bất động sản <span style="color:#FF0000;">(*)</span>:</label>
								<select class="form-control" id="loaibatdongsan" name="loai_bat_dong_san">
									<option value="">Chọn loại bất động sản</option>
									<option value="Nhà">Nhà</option>
									<option value="Biệt thự">Biệt thự</option>
									<option value="Mặt bằng">Mặt bằng</option>
								</select>
							</div>
							<div class="form-group">
								<label for="tinhthanh">Tỉnh thành <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="tinhthanh" placeholder="Tỉnh thành" name="tinh_thanh" value="<?php echo e(old('tinh_thanh')); ?>">
							</div>
							<div class="form-group">
								<label for="gia">Giá <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="gia" placeholder="Giá" name="gia" value="<?php echo e(old('gia')); ?>">
							</div>
							<div class="form-group">
								<label for="dientich">Diện tích <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="dientich" placeholder="Diện tích" name="dien_tich" value="<?php echo e(old('dien_tich')); ?>">
							</div>
							<div class="form-group">
								<label for="huong">Hướng:</label>
								<input type="text" class="form-control" id="hương" placeholder="Hướng" name="huong" value="<?php echo e(old('huong')); ?>">
							</div>
							<div class="form-group">
								<label for="tenlienhe">Tên liên hệ <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="tenlienhe" placeholder="Tên liên hệ" name="ten_lien_he" value="<?php echo e(old('ten_lien_he')); ?>">
							</div>
							<div class="form-group">
								<label for="sodienthoai">Số điện thoại <span style="color:#FF0000;">(*)</span>:</label>
								<input type="text" class="form-control" id="sodienthoai" placeholder="Số điện thoại" name="so_dien_thoai" value="<?php echo e(old('so_dien_thoai')); ?>">
							</div>
							<div class="form-group">
								<label for="diachi">Địa chỉ:</label>
								<input type="text" class="form-control" id="diachi" placeholder="Địa chỉ" name="dia_chi" value="<?php echo e(old('dia_chi')); ?>">
							</div>
							<div class="form-group">
								<label for="anhchinh">Ảnh chính <span style="color:#FF0000;">(*)</span>:</label>
								<input type="file" class="form-control" id="anhchinh" name="anh_chinh">
							</div>
							<div class="form-group">
								<label for="anhphu1">Ảnh phụ 1:</label>
								<input type="file" class="form-control" id="anhphu1" name="anh_phu_1">
							</div>
							<div class="form-group">
								<label for="anhphu1">Ảnh phụ 2:</label>
								<input type="file" class="form-control" id="anhphu2" name="anh_phu_2" >
							</div>
							<div class="form-group">
								<label for="anhphu1">Ảnh phụ 3:</label>
								<input type="file" class="form-control" id="anhphu3" name="anh_phu_3">
							</div>
							<?php echo e(csrf_field()); ?>

							<button type="submit" class="btn btn-primary">Đăng tin</button>
						</form>
					</div>
					<?php endif; ?>
					<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>