<?php $__env->startSection('title', 'QUẢN LÝ BÀI ĐĂNG'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">QUẢN LÝ BÀI ĐĂNG</h3>
						<?php if(count($errors) > 0): ?>
                          <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>  
                        <?php if(session('thongbao')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('thongbao')); ?>

                          </div>
                        <?php endif; ?>
						<table class="table table-bordered">
						    <thead>
						      <tr>
						      	<th>Trạng thái</th>
						        <th>Tiêu đề</th>
						        <th>Loại tin</th>
						        <th>Tỉnh thành</th>
						        <th>Ảnh</th>
						        <th>Xem</th>
						        <th>Sửa</th>
						        <th>Xóa</th>
						      </tr>
						    </thead>
						    <tbody>
						      <?php $__currentLoopData = $bai_dang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
						      <tr>
						      	<td><?php if($bd->trang_thai == 2): ?> Chưa duyệt <?php else: ?> Đã duyệt <?php endif; ?></td>
						        <td><?php echo e($bd->tieu_de); ?></td>
						        <td><?php echo e($bd->loai_tin); ?></td>
						        <td><?php echo e($bd->tinh_thanh); ?></td>
						        <td><img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bd->anh_chinh)); ?>" alt="<?php echo e($bd->tieu_de); ?>" style="width:100%;"></td>
						        <td><a href="<?php echo e(route('quan-ly-bai-dang-chi-tiet', ['id' => $bd->id])); ?>">Xem</a></td>
						        <td><a href="<?php echo e(route('sua-bai-dang-chi-tiet', ['id' => $bd->id])); ?>">Sửa</a></td>
						        <td><a href="<?php echo e(route('xoa-bai-dang-chi-tiet', ['id' => $bd->id])); ?>">Xóa</a></td>
						      </tr>
						      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>
					  	</table>
					  <div class="text-center"><?php echo $bai_dang->links(); ?></div>
					</div>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>