<?php $__env->startSection('title', 'BÀI ĐĂNG CHI TIẾT'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
						<h4 style="background-color:#3366FF; padding:5px; color:#FFFFFF;"><?php echo e($bai_dang->tieu_de); ?></h4>
						<hr style="border: 1px solid #BBBBBB;">
						<p><?php echo e($bai_dang->noi_dung); ?></p>
						<p>
							<span>Giá: <b style="color: #FF0000;"><?php echo e($bai_dang->gia); ?></b></span>
							<span style="margin-left:10px;">Diện tích: <b style="color: #FF0000;"><?php echo e($bai_dang->dien_tich); ?>m<sup>2</sup></b></span>
						</p>
						<p>Loại tin: <b><?php echo e($bai_dang->loai_tin); ?></b></p>
						<p>Loại bất động sản: <b><?php echo e($bai_dang->loai_bat_dong_san); ?></b></p>
						<p>Tỉnh thành: <b><?php echo e($bai_dang->tinh_thanh); ?></b></p>
						<?php if($bai_dang->dia_chi != ''): ?>
						<p>Địa chỉ: <b><?php echo e($bai_dang->dia_chi); ?></b></p>
						<?php endif; ?>
						<p>
							<span>Liên hệ: <b style="color: #FF0000;"><?php echo e($bai_dang->ten_lien_he); ?></b></span>
							<span style="margin-left:10px;">Số điện thoại: <b style="color: #FF0000;"><?php echo e($bai_dang->so_dien_thoai); ?></b></span>
						</p>
						<b>Hình ảnh:</b>
						<img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bai_dang->anh_chinh)); ?>" alt="<?php echo e($bai_dang->tieu_de); ?>" style="width:100%;">
						<?php if($bai_dang->anh_phu_1 != ''): ?>
						<img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bai_dang->anh_phu_1)); ?>" alt="<?php echo e($bai_dang->tieu_de); ?>" style="width:100%;">
						<?php endif; ?>
						<?php if($bai_dang->anh_phu_2 != ''): ?>
						<img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bai_dang->anh_phu_2)); ?>" alt="<?php echo e($bai_dang->tieu_de); ?>" style="width:100%;">
						<?php endif; ?>
						<?php if($bai_dang->anh_phu_3 != ''): ?>
						<img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bai_dang->anh_phu_3)); ?>" alt="<?php echo e($bai_dang->tieu_de); ?>" style="width:100%;">
						<?php endif; ?>
					</div>
					<?php echo $__env->make('partials.tin-ben-phai', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>