<?php $__env->startSection('title', 'Sửa Slide'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<?php if(!session('id_thanh_vien')): ?>
					<div class="col-xs-12">
						<div class="alert alert-warning">
						  <h3>Bạn phải đăng nhập mới có thể sửa slide!</h3>
						</div>
					</div>
					<?php else: ?>
					<div class="col-xs-12">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">SỬA SLIDE</h3>
						<form action="/cap-nhat-slide/<?php echo e($slide->id); ?>" method="post" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<div class="form-group">
								<img src="/img/<?php echo e($slide->image); ?>" alt="">
							</div>
							<div class="form-group">
								<label for="anhchinh">Hình ảnh <span style="color:#FF0000;">(*)</span>:</label>
								<input type="file" class="form-control" name="hinhanh">
							</div>
							<button type="submit" class="btn btn-primary">Cập nhật</button>
						</form>
					</div>
					<?php endif; ?>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>