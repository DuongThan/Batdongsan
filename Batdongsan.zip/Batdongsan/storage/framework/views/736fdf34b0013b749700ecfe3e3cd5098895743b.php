<?php $__env->startSection('title', 'Chi tiết liên hệ'); ?>
<?php $__env->startSection('noidung'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
            <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="giuatrang" class="row">
                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
                <?php if(!session('id_thanh_vien')): ?>
                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                    <div class="alert alert-warning">
                        <h3>Bạn phải đăng nhập mới có thể xem liên hệ!</h3>
                    </div>
                </div>
                <?php else: ?>
                <div class="col-xs-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <span class="hotel-search-label">Họ và tên:</span>
                                <input readonly value="<?php echo e($lienhe->ho_ten); ?>" type="text" name="ho_ten" class="form-control">
                            </div>
                            <div class="form-group">
                                <span class="hotel-search-label">Email:</span>
                                <input readonly value="<?php echo e($lienhe->email); ?>" type="text" name="email" class="form-control">
                            </div>
                            <div class="form-group">
                                <span class="hotel-search-label">Số điện thoại:</span>
                                <input readonly value="<?php echo e($lienhe->so_dien_thoai); ?>" type="text" name="so_dien_thoai" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <span class="hotel-search-label">Yêu cầu thêm:</span>
                                <textarea readonly name="yeu_cau" rows="5" class="form-control"><?php echo e($lienhe->yeu_cau); ?></textarea>
                            </div>
                        </div>
                            <div class="col-md-12 text-center">
                                <a href="/danh-sach-lien-he" class="btn btn-primary"">Trở về</a>
                            </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <br>
            <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>