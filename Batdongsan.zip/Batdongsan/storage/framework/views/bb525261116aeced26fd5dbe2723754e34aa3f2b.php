<?php $__env->startSection('title', 'ĐĂNG KÝ'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
					<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">ĐĂNG KÝ THÀNH VIÊN</h3>
						<?php if(count($errors) > 0): ?>
                          <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>
                        <?php if(isset($loi)): ?>
                          <div class="alert alert-warning">
                              <?php echo e($loi); ?> <br>
                          </div>
                        <?php endif; ?>    
                        <?php if(session('thongbao')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('thongbao')); ?>

                          </div>
                        <?php endif; ?>
						<form action="<?php echo e(route('dang-ky')); ?>" method="post">
							<div class="form-group">
								<label for="email">Email <span style="color:#FF0000;">(*)</span>:</label>
								<input type="email" class="form-control" id="email" name="email">
							</div>
							<div class="form-group">
								<label for="matkhau">Mật khẩu <span style="color:#FF0000;">(*)</span>:</label>
								<input type="password" class="form-control" id="matkhau" name="mat_khau">
							</div>
							<div class="form-group">
								<label for="nhaplaimatkhau">Nhập lại mật khẩu <span style="color:#FF0000;">(*)</span>:</label>
								<input type="password" class="form-control" id="nhaplaimatkhau" name="nhap_lai_mat_khau">
							</div>
							<div class="form-group">
								<label for="hoten">Họ tên:</label>
								<input type="text" class="form-control" id="hoten" name="ho_ten">
							</div>
							<div class="form-group">
								<label for="sodienthoai">Số điện thoại:</label>
								<input type="text" class="form-control" id="sodienthoai" name="so_dien_thoai">
							</div>
							<div class="form-group">
								<label for="diachi">Địa chỉ:</label>
								<input type="text" class="form-control" id="diachi" name="dia_chi">
							</div>
							<?php echo e(csrf_field()); ?>

							<button type="submit" class="btn btn-primary">Đăng ký</button>
						</form>
					</div>
					<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>