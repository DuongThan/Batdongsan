<?php $__env->startSection('title', 'QUẢN LÝ THÀNH VIÊN'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">QUẢN LÝ THÀNH VIÊN</h3>
						<?php if(count($errors) > 0): ?>
                          <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>  
                        <?php if(session('thongbao')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('thongbao')); ?>

                          </div>
                        <?php endif; ?>
						<table class="table table-bordered">
						    <thead>
						      <tr>
						      	<th>Kiểu thành viên</th>
						        <th>Email</th>
						        <th>Họ tên</th>
						        <th>Số điện thoại</th>
						        <th>Địa chỉ</th>
						        <th>Xóa</th>
						      </tr>
						    </thead>
						    <tbody>
						      <?php $__currentLoopData = $thanh_vien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
						      <tr>
						      	<td><?php if($tv->kieu_thanh_vien == 2): ?> Khách hàng <?php else: ?> Admin <?php endif; ?></td>
						        <td><?php echo e($tv->email); ?></td>
						        <td><?php echo e($tv->ho_ten); ?></td>
						        <td><?php echo e($tv->so_dien_thoai); ?></td>
						        <td><?php echo e($tv->dia_chi); ?></td>
						        <td><a href="<?php echo e(route('xoa-thanh-vien-chi-tiet', ['id' => $tv->id])); ?>">Xóa</a></td>
						      </tr>
						      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>
					  	</table>
					  	<div class="text-center"><a href="<?php echo e(route('them-thanh-vien')); ?>" class="btn-primary" style="padding: 5px;">Thêm thành viên</a></div>
					  <div class="text-center"><?php echo $thanh_vien->links(); ?></div>
					</div>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>