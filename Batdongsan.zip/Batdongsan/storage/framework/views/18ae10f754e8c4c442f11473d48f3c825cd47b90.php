<?php $__env->startSection('title', 'QUẢN LÝ BÀI ĐĂNG'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<h3 style="background-color:#3366FF; padding:5px; color:#FFFFFF; text-align:center;">QUẢN LÝ BÀI ĐĂNG</h3>
						<?php if(count($errors) > 0): ?>
                          <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>  
                        <?php if(session('thongbao')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('thongbao')); ?>

                          </div>
                        <?php endif; ?>
                        <img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bai_dang->anh_chinh)); ?>" alt="<?php echo e($bai_dang->tieu_de); ?>" style="width:100%;"><hr>
						<p><b>Trạng thái:</b> <?php if($bai_dang->trang_thai == 2): ?> Chưa duyệt  <?php else: ?> Đã duyệt <?php endif; ?></p>
						<p><b>Tiêu đề:</b> <?php echo e($bai_dang->tieu_de); ?></p>
						<p><b>Nội dung:</b> <?php echo e($bai_dang->noi_dung); ?></p>
						<p><b>Loại tin:</b> <?php echo e($bai_dang->loai_tin); ?></p>
						<p><b>Loại bất động sản:</b> <?php echo e($bai_dang->loai_bat_dong_san); ?></p>
						<p><b>Tỉnh thành:</b> <?php echo e($bai_dang->tinh_thanh); ?></p>
						<p><b>Giá:</b> <?php echo e($bai_dang->gia); ?></p>
						<p><b>Diện tích:</b> <?php echo e($bai_dang->dien_tich); ?></p>
						<p><b>Hướng:</b> <?php echo e($bai_dang->huong); ?></p>
						<p><b>Tên liên hệ:</b> <?php echo e($bai_dang->ten_lien_he); ?></p>
						<p><b>Số điện thoại:</b> <?php echo e($bai_dang->so_dien_thoai); ?></p>
						<p><b>Địa chỉ:</b> <?php echo e($bai_dang->dia_chi); ?></p>
						<?php if($bai_dang->trang_thai == 2): ?>
						<a href="<?php echo e(route('duyet-bai-dang-chi-tiet', ['id' => $bai_dang->id])); ?>" class="btn btn-primary">Duyệt bài đăng</a>
						<?php endif; ?>
					</div>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>