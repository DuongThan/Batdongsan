<?php $__env->startSection('title', 'NHÀ ĐẤT BÁN'); ?>
<?php $__env->startSection('noidung'); ?>
	<div class="container-fluid">
		<div class="row">
			<?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
				<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div id="giuatrang" class="row">
					<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
						<h4 style="background-color:#3366FF; padding:5px; color:#FFFFFF;">NHÀ ĐẤT BÁN</h4>
						<?php $__currentLoopData = $bai_dang_da_duyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bddd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<h5><a href="<?php echo e(route('bai-dang-chi-tiet', ['id' => $bddd->id])); ?>" style="color:#880000;"><b><?php echo e($bddd->tieu_de); ?></b></a></h5>
							</div>
							<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
								<a href="<?php echo e(route('bai-dang-chi-tiet', ['id' => $bddd->id])); ?>"><img class="img-responsive" src="<?php echo e(URL::to('/img/anh-bai-dang/'.$bddd->anh_chinh)); ?>" alt="<?php echo e($bddd->tieu_de); ?>" style="width:100%;"></a>
							</div>
							<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
								<p>
									<?php if(strlen($bddd->noi_dung) > 300): ?>
									<?php echo e(mb_substr($bddd->noi_dung, 0, 300)); ?> ...
									<?php else: ?>
									<?php echo e($bddd->noi_dung); ?>

									<?php endif; ?>
								</p>
								<a href="<?php echo e(route('bai-dang-chi-tiet', ['id' => $bddd->id])); ?>">Xem chi tiết >></a>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="text-center"><?php echo $bai_dang_da_duyet->links(); ?></div>
					</div>
					<?php echo $__env->make('partials.tin-ben-phai', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<br>
				<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>	
			<?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>