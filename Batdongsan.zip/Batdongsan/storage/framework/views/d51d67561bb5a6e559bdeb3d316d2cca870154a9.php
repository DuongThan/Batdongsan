<?php $__env->startSection('title', 'Liên hệ'); ?>
<?php $__env->startSection('noidung'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('partials.left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="giua" class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="background-color: #EEEEEE;">
            <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="giuatrang" class="row">
                <div class="col-xs-12">
                    <h4 style="background-color:#3366FF; padding:5px; color:#FFFFFF;">Thông tin liên hệ</h4>
                    <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <?php if(session('thongbao')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('thongbao')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <form method="post" action="/them-lien-he">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <span class="hotel-search-label">Họ và tên:</span>
                                    <input require value="" type="text" name="ho_ten" class="form-control">
                                </div>
                                <div class="form-group">
                                    <span class="hotel-search-label">Email:</span>
                                    <input require value="" type="text" name="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <span class="hotel-search-label">Số điện thoại:</span>
                                    <input require value="" type="text" name="so_dien_thoai" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <span class="hotel-search-label">Yêu cầu thêm:</span>
                                    <textarea name="yeu_cau" value=" " rows="5" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12 text-center">
                                <button class="btn btn-primary" type="submit">Gửi</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <br>
            <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('partials.right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>