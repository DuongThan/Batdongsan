				<div id="cuoitrang">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:20px; text-align:center; background-color:#BBBBBB;">
							<h3>CÔNG TY BẤT ĐỘNG SẢN X</h3>
							<p>Xuân Thủy, Quận Cầu Giấy, Hà Nội</p>
							<p>0123456789</p>
						</div>
					</div>
				</div>