-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 16, 2018 lúc 08:56 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `batdongsan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bai_dang`
--

CREATE TABLE `bai_dang` (
  `id` int(11) NOT NULL,
  `id_thanh_vien` int(11) NOT NULL,
  `trang_thai` int(11) NOT NULL,
  `tieu_de` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `loai_tin` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `loai_bat_dong_san` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tinh_thanh` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gia` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dien_tich` float NOT NULL,
  `huong` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_lien_he` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `so_dien_thoai` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `anh_chinh` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `anh_phu_1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anh_phu_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anh_phu_3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `bai_dang`
--

INSERT INTO `bai_dang` (`id`, `id_thanh_vien`, `trang_thai`, `tieu_de`, `noi_dung`, `loai_tin`, `loai_bat_dong_san`, `tinh_thanh`, `gia`, `dien_tich`, `huong`, `ten_lien_he`, `so_dien_thoai`, `dia_chi`, `anh_chinh`, `anh_phu_1`, `anh_phu_2`, `anh_phu_3`) VALUES
(5, 3, 1, 'TÔI VỀ QUÊ CẦN BÁN LẠI LÔ ĐẤT TL10 BÌNH CHÁNH ,SHR, THỔ CƯ 100%, 100M2/ 890TR', '+ Đất nằm ngay Tỉnh Lộ 10 - Trần Văn Giàu -  TP. HCM.\r\n+ Liền kề các cụm khu công nghiệp Lê Minh Xuân 3, An Hạ, Tân Đô, Hải Sơn, Liên Minh....\r\n+ Gần ngay:\r\n Điện máy xanh, Ngân hàng : Agribank, sacombank , Điện máy chợ lớn , Trường cấp 1,2\r\n+ Vị trí rất đẹp như hình ,đường trước nhà  12m, xung quanh dân cư tập trung đông.\r\n+ Thích hợp xây trọ cho thuê kinh doanh.\r\n+ Sổ hồng đầy đủ , bao giấy phép xây dựng\r\n+ lh 0909765359 Hương', 'Cần bán', 'Nhà', 'Hồ Chí Minh', '890 triệu', 100, 'Đông', 'Hà', '0123456789', 'Hà Nội', '20181207_092720_3613234_0.jpg', '', '', ''),
(6, 7, 2, 'Bán nhà Hoàng Mai, 5 tầng mới đẹp, ô tô quay đầu trước nhà, 45m2 giá 3.65 tỷ.', '-Giá chào 3.65 tỷ căn nhà :\r\n+DT 45m2, MT 4m.\r\n+Lô góc, 5 tầng mới đẹp, chắc chắn.\r\n+Trước nhà 3 ô tô tránh, quay đầu, nhà có việc chứa được 15 xe, dừng đỗ ngày đêm.\r\n+Nhà thiết kế nội thất đẹp, mỗi tầng 2 phòng ngủ, tổng có 6 phòng ngủ, lô góc nên phòng nào cũng có cửa sổ, thoáng tuyệt vời. \r\n+Gần chợ, trường. Hàng xóm cán bộ nhà nước nghỉ hưu, yên tĩnh, dân trí cao.\r\n+Sổ đỏ chính chủ, như phân lô.\r\n-Liên hệ 0973603458 tôi Lụa.', 'Cần bán', 'Nhà', 'Hà Nội', '3,65 tỷ', 45, 'Đông', 'Tuấn', '0123456789', 'Đường Định Công, Phường Định Công, Quận Hoàng Mai, Hà Nội', '20181207_044418_3821463_0.jpg', '20181207_044418_3821463_1.jpg', '20181207_044418_3821463_2.jpg', '20181207_044418_3821463_3.jpg'),
(7, 4, 1, 'Bán Đất', 'Cần bán một ô đất rộng mặt đường trên núi', 'Cần bán', 'Mặt bằng', 'Đà Nắng', '15000000', 40, 'Tây', 'Mr-Duy', '0989999999', 'BN', '1 - Copy.jpg', '', '', ''),
(9, 3, 1, 'Cần Bán Nhà Nhỏ 50m2, SHR, Hóc Môn, HCM. 550TR', 'Cần Bán Nhà Nhỏ 50m2, SHR, Hóc Môn, HCM. 550TR Kết cấu xây dựng: 1 trệt 3 lầu - Gồm: phòng khách, phòng bếp, 4 phòng ngủ, 3 nhà vệ sinh, sân thượng.Nội thất: Quầy bar, tủ kệ bếp, rèm cửa phòng ngủ,', 'Cần bán', 'Biệt thự', 'Hồ Chí Minh', '10000000000', 50, 'Bắc', 'Mr-Du', '0989999988', 'TP-Hồ CHí Minh', 'nha-dat-2-688174f22151.jpg', '', '', ''),
(10, 3, 1, 'Nhà Bán Chính Chủ Số Nhà Quận', 'Hem 85 đường số 8, bình hưng hòa b, bình tân Quận Bình Tân\r\nCần tiền bán gấp nhà để trả nợ Chính Chủ Cần Tiền Bán Gấp Nhà Pháp Lý: Số Nhà Quận 2003', 'Cần bán', 'Nhà', 'Hà Nội', '10000000000', 100, 'Đông', 'Mss Hà', '0166666666', 'Hà Nội', 'dat.jpg', '', '', ''),
(11, 3, 1, 'Bán Đất Mặt Tiền Đường Phú Thuận 23m X 29m Tổng Diện Tích: 600m2', 'Bán đất mặt tiền đường Phú Thuận 23m x 29m; Tổng diện tích: 600m2 (đất ở đô thị: 421m2 + đất nông nghiệp: 179m2).', 'Cần bán', 'Mặt bằng', 'Đà Nắng', '150000000', 600, 'Tây', 'Mr-Hoang', '0989999999', 'Hà Nội', 'le_phi_truoc_ba_UXHP_thumb.jpg', '', '', ''),
(12, 3, 1, 'Bán Nhà Văn Phòng 1 Trệt 2 Lầu Đường Trần Xuân Soạn, Quận 7, Tp.hcm', 'Bán nhà văn phòng 1 trệt 2 lầu đường Trần Xuân Soạn, Quận 7, TP.HCM. Mặt tiền đường và mặt tiền sông lớn. Thuận tiện giao thông đường bộ lẫn đường thủy', 'Cần bán', 'Nhà', 'Hà Nội', '15000000', 20, 'Đông', 'Long', '0989999988', 'Hà Nội', 'slide-4-940x588.jpg', '', '', ''),
(13, 3, 1, 'Hot hot! Bán nhà đẹp hẻm xe hơi, Dương Cát Lợi, Giáp Q7, Dt 5,5x11m, 3 lầu. Giá 3,8 tỷ', 'Nhà phố tại TP.Hồ Chí Minh. Tình trạng Sổ hồng. Tiện ích: Wifi, Đầy đủ nội thất, Ban công / Sân thượng, Internet cáp quang, Tìm Hiểu Ngay!', 'Cần bán', 'Nhà', 'Hồ Chí Minh', '1000000500', 100, 'Đông', 'Minh', '0966666665', 'TP-Hồ CHí Minh', 'nha-dat-2-688174f22151.jpg', '08_rcdf.jpg', '', ''),
(14, 3, 1, 'VĂN PHÒNG CHÍNH CHỦ 30-50-100M2 NGÃ 4 HOÀNG QUỐC VIỆT, GIÁ TỐT, SD NGAY, VỊ TRÍ ĐẸP (VIP*)', 'Cho thuê văn phòng 30m2 - 40m2 siêu đẹp tại số 146 Hoàng Quốc Việt, Cầu Giấy - view ngã tư thông thoáng.\r\n1/. Vị trí siêu đắc địa.\r\n- Tòa nhà nằm tại mặt phố lớn Hoàng Quốc Việt, nút giao ngã tư Hoàng Quốc Việt, trung tâm kinh tế phát triển, mặt đường rộng ngay ngã tư xe cộ lưu thông thuận tiện.\r\n- Nằm trong khu kinh doanh sầm uất, xung quanh tập trung nhiều tòa văn phòng và ngân hàng lớn, nhà hàng,... Rất thuận tiện cho việc giao dịch.\r\n- Vị trí đẹp, địa chỉ rõ ràng, dễ nhận diện công ty.\r\n- Khu đông dân, dân trí cao, an ninh đảm bảo.\r\n2/. Đặc điểm văn phòng:\r\n- DT cho thuê từ 30m2 - 40m2, MT rộng, view kính sang trọng.\r\n- Văn phòng cực đẹp: Sàn gỗ sang trọng, trần thạch cao, điều hòa, nóng lạnh, internet đầy đủ.\r\n- Có thang máy tốc độ cao, hầm để xe và bảo vệ 24/24h.\r\n3/. Phù hợp làm văn phòng công ty, lớp học, spa mini, kho + kinh doanh online, văn phòng du học - du lịch - XKLĐ...\r\n4/. Giá cho thuê.\r\n- Chỉ từ 7 triệu - 10 triệu/tháng.\r\n- Combo Full Dịch Vụ (full điện hành lang, thang máy, vệ sinh chung, bảo vệ, rác, free 3 xe máy...).\r\n- Có xuất hóa đơn VAT cho KH (nếu cần).\r\n- Thanh toán linh hoạt.\r\n- Khách hàng thuê không mất phí môi giới.', 'Cho Thuê', 'Nhà', 'Hà Nội', '7 triệu / tháng', 40, 'Đông', 'Ms Ngân', '0917.531.468 hoặc 0964.05.2828', '146 Đường Hoàng Quốc Việt, Phường Nghĩa Đô, Quận Cầu Giấy, Hà Nội', '20181127_032714_3767087_3.jpg', '20181127_032714_3767087_0.jpg', '20181127_032714_3767087_5.jpg', ''),
(15, 3, 1, 'TƯNG BỪNG KHAI TRƯƠNG KM 50% CHO THUÊ VP TRỌN GÓI T8 DETECH 107NGUYỄN PHONG SẮC 0869872222', 'MPRO OFFICE TƯNG BỪNG KHAI TRƯƠNG\r\nCƠ SỞ 2 TẦNG 8 DETECH TOWER 107 NGUYỄN PHONG SẮC \r\n Từ: 01/12 - 15/12 khuyến mãi 50% tiền thuê tháng đầu tiên \r\n \r\nTRẢI NGHIỆM DỊCH VỤ VĂN PHÒNG CHUYÊN NGHIỆP, ĐẲNG CẤP CỦA MPRO OFFICE VỚI GIÁ CỰC KỲ HẤP DẪN\r\n\r\n\r\nCho thuê văn phòng trọn gói chuyên nghiệp, văn phòng ảo, chỗ ngồi làm việc, cho thuê phòng họp tại Tòa nhà văn phòng tầng 8 Detech Tower II với đầy đủ tiện ích được thiết kế sang trọng, diện tích thuê từ 15 - 17 - 20 - 25 - 30 - 50 - 100m2 với giá thuê chỉ từ 8,5 triệu/tháng. Khách hàng chỉ việc mang máy tính đến làm việc, hàng tháng không phải lo chi trả bất kỳ một khoản chi phí nào khác.\r\nGiá trên đã bao gồm dịch vụ trọn gói tất cả các tiện ích:\r\n+ Khu tiện ích chung rộng và sang trọng.\r\n+ Được trang bị bàn, ghế, tủ tài liệu.\r\n+ Sảnh tiếp khách sang trọng, lịch sự, miễn phí trà, café, nước uống.\r\n+ Internet, wifi miễn phí, tốc độ cao.\r\n+ Phòng họp: 02 phòng hiện đại, có máy chiếu, tivi màn hình led với sức chứa lên tới 25 - 30 người.\r\n+ Lễ tân phục vụ trà, nước nhiệt tình, chu đáo, giao tiếp tiếng Anh tốt.\r\n+ Có máy in, máy photocopy sử dụng chung.\r\n+ Điện điều hòa, các thiết bị điện trong văn phòng làm việc.\r\n+ Khách hàng được đăng ký kinh doanh tại địa chỉ của tòa nhà.\r\n\r\nDetech Tower II nằm ở vị trí vô cùng đắc địa, tọa lạc ngay ngã ba của hai tuyến đường quan trọng của Quận Cầu Giấy là Nguyễn Phong Sắc và Trần Đăng Ninh. Khách hàng thuê tại đây dễ dàng tiếp cận một cách thuận lợi đến các khu vực khác của thành phố như: Lotte Center Hà Nội, Keangnam Landmard Tower, cảng sân bay quốc tế Nội Bài, cũng như di chuyển ra các khu vực lân cận quận Cầu Giấy.\r\nĐược đánh giá là một trong những tòa nhà văn phòng hạng B hiện đại và đẹp nhất của quận Cầu Giấy, Detech Tower II được trang bị đầy đủ các thiết bị tiện nghi của một văn phòng cao cấp; Tạo ra một không gian làm việc sang trọng, chuyên nghiệp, hiệu quả cho mọi khách thuê.\r\nTòa nhà Detech Tower II là tổ hợp gồm 17 tầng không gian văn phòng, kèm theo 1 tầng thương mại và 4 tầng hầm với tổng diện tích lên tới 6.500m2. Tổng diện tích sàn xây dựng khoảng 19.240m2. Hệ thống 5 thang Mitsubishi lifts (2,5m/s). Tải trọng 1.350kg (trong nhà). Hệ thống báo cháy địa chỉ, chữa cháy tự động spinler. Hệ thống chiếu sáng: Đèn Led, độ sáng 300 - 400 Lux.\r\nLàm việc tại Detech Tower II khách thuê được thừa hưởng rất nhiều tiện ích và dịch vụ xung quanh tòa nhà như ngân hàng, quán bar, cà phê, trung tâm thương mại và khách sạn cao cấp.', 'Cho Thuê', 'Nhà', 'Hà Nội', '600 ngàn / m2  / tháng', 15, 'Đông', 'CÔNG TY CỔ PHẦN ĐẦU TƯ MPRO', '0869872222', 'Cơ sở 2: Tầng 8 tòa nhà Detech Tower 2, số 107, đường Nguyễn Phong Sắc, Phường Dịch Vọng, TP Hà Nội.', '20181201_095809_3795147_0.jpg', '20181201_095809_3795147_2.jpg', '20181201_095809_3795147_5.jpg', ''),
(16, 3, 1, 'CHO THUÊ MẶT BẰNG ĐIỆN BIÊN PHỦ (HOẶC TÒA NHÀ RIÊNG) QUẬN 3, LIÊN HỆ: 0948707579 - MS.THẢO', 'Cần cho thuê gấp mặt bằng trên đường Điện Biên Phủ (hoặc cả tòa nhà) Quận 3, trung tâm thành phố, vị trí đẹp, lưu lượng giao thông lớn, thuận lợi,.. để làm văn phòng hoặc kinh doanh đều phù hợp cả.\r\n- Địa chỉ: 231 Điên Biên Phủ, Phường 6, Quận 3.\r\n1. Cho thuê tầng trệt và lầu 1\r\nDiện Tích: 300 m2\r\nGía thuê: 100.000.000 VNĐ/ tháng\r\nNếu thuê cả cơ sở vật chất : 130.000.000 VNĐ/ tháng\r\nNhà hàng đang làm quán Bar và Bếp chuẩn Âu, Quầy Bar cũng chuẩn Âu\r\nGợi ý: Làm quán coffee thì ok. Ví dụ: Anh/ Chị Mở cafe coffee house hay mấy chỗ muốn nhượng quyền. Thích hợp kinh doanh các ngành nghề\r\n2. Cho thuê cả tòa nhà:\r\nDiện tích: 150m2 x 6 sàn; Gồm 5 tầng và một sân thượng\r\nĐịa chỉ: 231 Điện Biên Phủ, Phường 6, Quận 3, Tp.HCM\r\nGía thuê full cơ sở vật chất: 300.000.000 VNĐ\r\nGía thuê không có cơ sở vật chất: 270.000.000 VNĐ', 'Cho Thuê', 'Mặt bằng', 'Hồ Chí Minh', '270 triệu / tháng', 900, '', 'MS.THẢO', '0948707579', '231 Đường Điện Biên Phủ, Phường 6, Quận 3, Hồ Chí Minh', '20181212_100425_3838182_0.jpg', '20181212_100425_3838182_5.jpg', '20181212_100425_3838182_4.jpg', '20181212_100425_3838182_1.jpg'),
(17, 3, 1, 'Cho thuê mặt bằng kinh doanh, showroom số 352 - 354 Phố Huế', 'Cho thuê mặt bằng kinh doanh, showroom số 352 - 354 Phố Huế, tầng 1+2: 500m2, mặt tiền 13.5m, 8tầng\r\nKhu vực: Cho thuê cửa hàng, ki ốt tại Phố Phố Huế - Quận Hai Bà Trưng - Hà NộiGiá: 200 triệu/tháng  Diện tích: 500m²\r\nThông tin mô tả\r\nCho thuê mặt bằng kinh doanh, showroom số 352 - 354 Phố Huế, ngay sau gần Vincom Bà Triệu, quận Hai Bà Trưng. \r\nDiện tích tòa nhà 355m2, 8 tầng, mặt tiền 13,5m. \r\nVị trí: Cách ngã tư Trần Khát Chân 100m, cạnh ngân hàng VP Bank, đối diện chợ Trời, BV Bưu Điện, xung quanh là các tuyến phố Bà Triệu, Triệu Việt Vương, Mai Hắc Đế, Bùi Thị Xuân... \r\nThiết kế: \r\nTầng 1: 270m2 \r\nTầng 2: 230m2 \r\nPhù hợp ngân hàng, shop thời trang, thẩm mỹ viện, phòng khám... \r\nTầng 3 - 8: diện tích 115m2, 155m2, 250m2 phù hợp văn phòng \r\nTiện ích tòa nhà: \r\n- Có tầng hầm để xe. \r\n- 02 hệ thống thang máy. \r\n- Hệ thống điều hòa âm trần. \r\n- Máy phát điện dự phòng. \r\n- Hệ thống PCCC tiêu chuẩn. \r\n- Bảo vệ 24/24h. \r\nƯu đãi. \r\n- Miễn phí 1 - 2 tháng setup văn phòng cho khách thuê. \r\n- Miễn phí hoàn toàn phí dịch vụ sử dụng tiện ích như: Thang máy, vệ sinh tòa nhà, làm thêm giờ... \r\nThời gian dự kiến đi vào hoạt động 01/2019. \r\n\r\nGiá thuê tầng 1 + 2: Từ 250 - 310 tr/th (tùy theo loại hình kinh doanh). \r\nGiá cho thuê chỉ từ 220 nghìn/m2/tháng.', 'Cho Thuê', 'Mặt bằng', 'Hà Nội', '600 ngàn / m2  / tháng', 250, '', 'Anh Mạnh', '0915339116', 'Phố Huế, Phường Phố Huế, Quận Hai Bà Trưng, Hà Nội', '20181206_092913_3814138_1.jpg', '20181207_113011_3814138_1.jpg', '20181207_113011_3814138_2.jpg', '20181207_113011_3814138_3.jpg'),
(18, 3, 1, 'Cho thuê văn phòng chính chủ tại đường Bùi Viện, quận 1', 'Tòa nhà FBuilding địa chỉ số 40/25 Bùi Viện, phường Phạm Ngũ Lão, quận 1, TPHCM.\r\nQuy mô: 1 hầm, 1 trệt, 6 lầu.\r\nDiện tích cho thuê: 98 – 100 – 105 m2\r\nGiá thỏa thuận\r\nĐặt cọc: 3 – 5 tháng tùy vào thời gian kí hợp đồng\r\nThời gian chuẩn bị mặt bằng: 15 ngày\r\nTiện ích: \r\n	Có hầm giữ xe\r\n	Được trang bị thang máy 2018\r\n	Hệ thống camera, hệ thống cáp quang lắp đặt internet, điện chiếu sáng khu vực công cộng\r\n	Hệ thống phòng cháy chữa cháy……\r\n	Mặt bằng phù hợp kinh doanh nhà hàng, văn phòng, trung tâm Anh ngữ\r\nLiên hệ trực tiếp đại diện chủ đầu tư: Anh Nguyễn Anh Tuấn – SĐT 093.603.3883 hoặc email: tuan.nguyenanh@fgb.vn', 'Cho Thuê', 'Nhà', 'Hồ Chí Minh', '60 triệu / tháng', 100, '', 'Anh Nguyễn Anh Tuấn', '093.603.3883', '40/25 Đường Bùi Viện, Phường Phạm Ngũ Lão, Quận 1, Hồ Chí Minh', '20181210_092013_3828150_0.jpg', '20181210_092013_3828150_1.jpg', '20181212_100644_3828150_1.jpg', ''),
(19, 3, 1, 'CẦN CHO THUÊ KHÁCH SẠN ĐƯỜNG HỒ NGHINH', 'Mặt tiền hồ nghinh. 7 tầng 21 phòng. \r\nCó thang máy và tầng hầm để xe \r\nGần trung tâm du lịch \r\nBạn có thể đến trung tâm thành phố chỉ mất 5p \r\nVà ba phút để đến siêu thị\r\nVà 10p đến Chùa Linh Ứng\r\nGiá thuê 85 có thương lượng thanh toán 6 cọc 3 \r\nLiên hệ 0932424347 để được tư vấn thêm', 'Cho Thuê', 'Nhà', 'Đà Nẵng', '85 triệu / tháng', 100, '', 'Trần Văn Trung', '0932424347', 'Đường Hồ Nghinh, Phường Phước Mỹ, Quận Sơn Trà, Đà Nẵng', '20181212_081751_3841390_0.jpg', '20181212_081751_3841390_2.jpg', '20181212_081751_3841390_4.jpg', ''),
(20, 3, 1, 'Chính chủ Cho thuê nhà mặt tiền, khu đô thị đại dương, tp bắc ninh, cách ngã 6 500m', '(※Giá cả có thương lượng※) Ngôi nhà được thiết kế hiện đại trên diện tích 140m2/sàn x 4,5 tầng hướng Đông Nam.\r\nNhà có 6 phòng ngủ + 3 phòng khách rộng rãi, khép kín, tiện nghi. Được trang bị nội thất đầy đủ, phòng khách, bếp rộng thoáng, điều hòa 2 chiều, nóng lạnh trang bị từng phòng. Nhà nằm trên mặt chính đường Nguyễn Quyền rộng 30m, vỉa lớn cách ngã 6 TP. Bắc Ninh 500m.\r\n\r\nVị trí trung tâm, gần Viện Đa Khoa Bắc Ninh và Viện Nhi mới, gần Công viên Nguyễn Văn Cừ - Hồ điều hòa Văn Miếu. Rất phù hợp cho các tổ chức, cá nhân trong và ngoài nước thuê làm văn phòng, công ty hoặc nơi nghỉ dưỡng cho cán bộ nhân viên... Phòng khám, hiệu thuốc.\r\n\r\n***Liên hệ chính chủ: Chú Thảo (098 689 9908) Cô Thảnh (0334 982 109).\r\n(**Có thương lượng)', 'Cho Thuê', 'Nhà', 'Bắc Ninh', '25 triệu / tháng', 140, '', 'Đỗ Thảo', '098 689 9908', 'Số nhà 22 Đường Nguyễn Quyền, Phường Đại Phúc, Thành phố Bắc Ninh, Bắc Ninh', '20181014_071403_3592055_0.jpg', '20181014_071403_3592055_2.jpg', '20181014_071403_3592055_3.jpg', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bo_phieu`
--

CREATE TABLE `bo_phieu` (
  `id` int(11) NOT NULL,
  `hinh_thuc` longtext NOT NULL,
  `so_luong` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `bo_phieu`
--

INSERT INTO `bo_phieu` (`id`, `hinh_thuc`, `so_luong`) VALUES
(1, 'Google.com,...', 1),
(2, 'Báo chí, truyền hình...', 0),
(3, 'Mạng xã hội', 0),
(4, 'Bạn bè giới thiệu', 0),
(5, 'Khác', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lien_he`
--

CREATE TABLE `lien_he` (
  `id` int(11) NOT NULL,
  `ho_ten` longtext NOT NULL,
  `so_dien_thoai` longtext NOT NULL,
  `email` longtext NOT NULL,
  `yeu_cau` longtext,
  `ngay_lien_he` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `lien_he`
--

INSERT INTO `lien_he` (`id`, `ho_ten`, `so_dien_thoai`, `email`, `yeu_cau`, `ngay_lien_he`) VALUES
(3, 'sd', 'sd', 's', 'sd', '2018-12-16 06:22:02');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `hinh_anh` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `slide`
--

INSERT INTO `slide` (`id`, `hinh_anh`) VALUES
(3, '1811_DuXuanxuDai.jpg'),
(4, '1811_hanquocTetKyHoi.jpg'),
(5, '1811_NhatTet.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thanhvien_bophieu`
--

CREATE TABLE `thanhvien_bophieu` (
  `id` int(11) NOT NULL,
  `id_thanh_vien` int(11) NOT NULL,
  `id_phieu` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `thanhvien_bophieu`
--

INSERT INTO `thanhvien_bophieu` (`id`, `id_thanh_vien`, `id_phieu`, `date`) VALUES
(4, 3, 1, '2018-12-16 14:42:29');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thanh_vien`
--

CREATE TABLE `thanh_vien` (
  `id` int(11) NOT NULL,
  `kieu_thanh_vien` tinyint(4) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mat_khau` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ho_ten` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `so_dien_thoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thanh_vien`
--

INSERT INTO `thanh_vien` (`id`, `kieu_thanh_vien`, `email`, `mat_khau`, `ho_ten`, `so_dien_thoai`, `dia_chi`) VALUES
(3, 1, 'ha@gmail.com', '123456', 'Hà', '', ''),
(4, 2, 'duy@gmail.com', '123456', 'Duy', '', ''),
(7, 2, 'tuan@gmail.com', '123456', 'Tuấn', '0123456787', 'Hà Nội'),
(8, 2, 'hang@gmail.com', '123456', 'Hằng', '0987654321', 'Hà Nội'),
(9, 1, 'linhxotic@gmail.com', '123456', 'Linh', '123456789', 'Hà Nội');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bai_dang`
--
ALTER TABLE `bai_dang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_thanh_vien` (`id_thanh_vien`);

--
-- Chỉ mục cho bảng `bo_phieu`
--
ALTER TABLE `bo_phieu`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `lien_he`
--
ALTER TABLE `lien_he`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `thanhvien_bophieu`
--
ALTER TABLE `thanhvien_bophieu`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `thanh_vien`
--
ALTER TABLE `thanh_vien`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bai_dang`
--
ALTER TABLE `bai_dang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `bo_phieu`
--
ALTER TABLE `bo_phieu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `lien_he`
--
ALTER TABLE `lien_he`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `thanhvien_bophieu`
--
ALTER TABLE `thanhvien_bophieu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `thanh_vien`
--
ALTER TABLE `thanh_vien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bai_dang`
--
ALTER TABLE `bai_dang`
  ADD CONSTRAINT `bai_dang_ibfk_1` FOREIGN KEY (`id_thanh_vien`) REFERENCES `thanh_vien` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
